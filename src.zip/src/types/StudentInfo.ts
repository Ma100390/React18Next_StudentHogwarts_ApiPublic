export type StudentInfo = {
    id:string,
    name:string,
    species:string,
    house:string,
    wizard:boolean,
    image:string,
}