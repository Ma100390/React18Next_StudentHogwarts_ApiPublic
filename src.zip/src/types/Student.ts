export type Student = {
    id:string,
    name:string,
    house:string,
    wizard:boolean,
    image:string
}